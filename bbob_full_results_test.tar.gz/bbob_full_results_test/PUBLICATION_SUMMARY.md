# Full BBOB SOMA/DE benchmark summary

## Experimental design

- BBOB functions: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24] (default f1--f24), organized into groups 1--5.
- Dimensions: [5, 10]
- Budgets: [500] function evaluations per dimension.
- BBOB instances: [1, 2, 3, 4, 5]
- Independent repeats per instance: 10
- Requested algorithms: ['Canonical-SOMA', 'GC-SOMA', 'RA-SOMA', 'iSOMA', 'iL-SHOMA-RA', 'SciPy-DE', 'iL-SHADE']
- Matched initial population: 4D.
- Canonical SOMA population: 10D.
- Target errors: [100.0, 10.0, 1.0, 0.1, 0.01, 0.001, 0.0001, 1e-05, 1e-06, 1e-07, 1e-08]
- Absolute final error relative to the BBOB optimum is the primary performance value.
- Repeated runs are aggregated within each function-instance block before ranks and paired tests.
- GC-SOMA, RA-SOMA, iSOMA, iL-SHOMA-RA, and SciPy-DE use a shared initial population within each block when their population sizes match.
- iL-SHADE uses PyADE package defaults; iL-SHADE-matched overrides only the initial population size.

## Overall algorithm summaries

### Dimension 5, budget 500 FE/D

| algorithm | n_runs | median_best_error | median_absolute_auc_normalized | average_rank | mean_seconds |
| --- | --- | --- | --- | --- | --- |
| SciPy-DE | 1200 | 0.078342 | 0.014888 | 2.6833 | 0.037175 |
| iL-SHADE | 1200 | 0.66849 | 0.025439 | 3.1708 | 0.062449 |
| RA-SOMA | 1200 | 0.29606 | 0.022243 | 3.175 | 0.028943 |
| iL-SHOMA-RA | 1200 | 1.1884 | 0.015332 | 3.6625 | 0.059434 |
| GC-SOMA | 1200 | 1.0887 | 0.024298 | 4.0667 | 0.05847 |
| iSOMA | 1200 | 1.4923 | 0.028713 | 4.4083 | 0.026581 |
| Canonical-SOMA | 1200 | 10.55 | 0.071434 | 6.8333 | 0.012381 |

### Dimension 10, budget 500 FE/D

| algorithm | n_runs | median_best_error | median_absolute_auc_normalized | average_rank | mean_seconds |
| --- | --- | --- | --- | --- | --- |
| iL-SHADE | 1200 | 1.8547 | 0.035342 | 2.475 | 0.10451 |
| SciPy-DE | 1200 | 1.9579 | 0.027644 | 2.9 | 0.077541 |
| iL-SHOMA-RA | 1200 | 2.5834 | 0.022134 | 3.2458 | 0.11592 |
| RA-SOMA | 1200 | 3.0514 | 0.036807 | 3.8917 | 0.05923 |
| iSOMA | 1200 | 5.0844 | 0.036694 | 4.0875 | 0.052785 |
| GC-SOMA | 1200 | 7.3692 | 0.042193 | 4.4667 | 0.11826 |
| Canonical-SOMA | 1200 | 90.674 | 0.13819 | 6.9333 | 0.026661 |

## Friedman tests

| dimension | budget_per_dimension | scope | group_id | n_blocks | n_algorithms | friedman_statistic | friedman_pvalue |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 5 | 500 | overall | None | 120 | 7 | 310.92 | 3.7446e-64 |
| 5 | 500 | group | g1 | 25 | 7 | 59.025 | 7.1013e-11 |
| 5 | 500 | group | g2 | 20 | 7 | 81.909 | 1.4406e-15 |
| 5 | 500 | group | g3 | 25 | 7 | 124.83 | 1.5706e-24 |
| 5 | 500 | group | g4 | 25 | 7 | 65.818 | 2.9361e-12 |
| 5 | 500 | group | g5 | 25 | 7 | 52.2 | 1.6999e-09 |
| 10 | 500 | overall | None | 120 | 7 | 346.35 | 9.3792e-72 |
| 10 | 500 | group | g1 | 25 | 7 | 73.266 | 8.7261e-14 |
| 10 | 500 | group | g2 | 20 | 7 | 88.8 | 5.378e-17 |
| 10 | 500 | group | g3 | 25 | 7 | 122.69 | 4.4319e-24 |
| 10 | 500 | group | g4 | 25 | 7 | 85.545 | 2.5456e-16 |
| 10 | 500 | group | g5 | 25 | 7 | 62.709 | 1.2655e-11 |

## Generated publication data

- `benchmark_raw.csv`: one row per optimizer run.
- `convergence_curves.csv`: sampled best-so-far absolute-error histories.
- `target_hits_raw.csv`: run-level target attainment and censored FE counts.
- `mechanism_diagnostics.csv`: GC-SOMA target tracking and iL-SHOMA-RA adaptation/population traces.
- `final_performance_summary.csv`: per-function aggregate error, AUC, and runtime statistics.
- `function_instance_block_scores.csv`: repeated-run medians and absolute-error ranks.
- `average_ranks.csv`: overall and group-specific average ranks.
- `target_attainment_by_function.csv`: success rates and ERT by function.
- `target_attainment_overall.csv`: overall/group success rates and ERT.
- `friedman_tests.csv`: omnibus tests on complete function-instance blocks.
- `pairwise_wilcoxon_holm.csv`: paired tests, Holm correction, effect summaries, and win/tie/loss counts.
- `overall_algorithm_summary.csv`: compact overall performance table.

## Generated figures

- `convergence_group1_separable_d5_bpd500.png`
- `convergence_group1_separable_d5_bpd500.pdf`
- `convergence_group2_low_moderate_conditioning_d5_bpd500.png`
- `convergence_group2_low_moderate_conditioning_d5_bpd500.pdf`
- `convergence_group3_high_conditioning_unimodal_d5_bpd500.png`
- `convergence_group3_high_conditioning_unimodal_d5_bpd500.pdf`
- `convergence_group4_multimodal_adequate_structure_d5_bpd500.png`
- `convergence_group4_multimodal_adequate_structure_d5_bpd500.pdf`
- `convergence_group5_multimodal_weak_structure_d5_bpd500.png`
- `convergence_group5_multimodal_weak_structure_d5_bpd500.pdf`
- `convergence_group1_separable_d10_bpd500.png`
- `convergence_group1_separable_d10_bpd500.pdf`
- `convergence_group2_low_moderate_conditioning_d10_bpd500.png`
- `convergence_group2_low_moderate_conditioning_d10_bpd500.pdf`
- `convergence_group3_high_conditioning_unimodal_d10_bpd500.png`
- `convergence_group3_high_conditioning_unimodal_d10_bpd500.pdf`
- `convergence_group4_multimodal_adequate_structure_d10_bpd500.png`
- `convergence_group4_multimodal_adequate_structure_d10_bpd500.pdf`
- `convergence_group5_multimodal_weak_structure_d10_bpd500.png`
- `convergence_group5_multimodal_weak_structure_d10_bpd500.pdf`
- `target_ecdf_bpd500.png`
- `target_ecdf_bpd500.pdf`
- `average_ranks_bpd500.png`
- `average_ranks_bpd500.pdf`
- `gc_soma_active_dimension.png`
- `gc_soma_active_dimension.pdf`
- `gc_soma_contraction.png`
- `gc_soma_contraction.pdf`
- `ilshoma_ra_population_success.png`
- `ilshoma_ra_population_success.pdf`
- `ilshoma_ra_adaptation.png`
- `ilshoma_ra_adaptation.pdf`

## Interpretation note

The experimental iL-SHOMA-RA method is a new composite optimizer rather than a published reference implementation. Its results should be presented as exploratory until its components are ablated. Optional RA-SOMA-random and RA-SOMA-fixed runs can be enabled through `--algorithms` to distinguish covariance-informed orientation from generic orthogonal remapping. Any fallback iL-SHADE labels indicate development-only runs and must not be reported as PyADE iL-SHADE.